jQuery('document').ready(function($){
   var menuBtn = $('.menu-icon');
   var menu = $('.navigation ul');
   var cedulas = new Array();
   var estudiantes = new Array();
   var edades = new Array();
   var matrices=new Array();
   var objestudiantes=new Array();
   
   var formulario=document.getElementById('formulario');
          formulario.addEventListener('submit',function(e){
           e.preventDefault();
        })
  

   
      menuBtn.click(function(){


        if (menu.hasClass('show')) {
          menu.removeClass('show');
        }else{
          menu.addClass('show');
      
        };
      });

        //matrices
$("#boton_matriz_agregar").click(function () {
    var numFilas = parseInt(prompt('Ingrese el número de filas:'));
    var numColumnas = parseInt(prompt('Ingrese el número de columnas:'));

    var matrizNueva = [];

    for (var i = 0; i < numFilas; i++) {
        matrizNueva[i] = new Array(numColumnas);
        for (var j = 0; j < numColumnas; j++) {
            matrizNueva[i][j] = parseInt(prompt('Ingrese el valor para la posición [' + i + '][' + j + ']:'));
        }
    }

    // Mostrar la matriz ingresada por el usuario
    var matrizAlerta = 'Matriz ingresada:\n';
    for (var i = 0; i < numFilas; i++) {
        matrizAlerta += matrizNueva[i].join('\t') + '\n';
    }
    alert(matrizAlerta);

    // Calcular suma de filas, columnas y diagonal principal
    var sumaFilasAlerta = 'Suma de filas:\n';
    for (var i = 0; i < numFilas; i++) {
        var sumaFila = 0;
        for (var j = 0; j < numColumnas; j++) {
            sumaFila += matrizNueva[i][j];
        }
        sumaFilasAlerta += 'Fila ' + i + ': ' + sumaFila + '\n';
    }

    var sumaColumnasAlerta = 'Suma de columnas:\n';
    for (var j = 0; j < numColumnas; j++) {
        var sumaColumna = 0;
        for (var i = 0; i < numFilas; i++) {
            sumaColumna += matrizNueva[i][j];
        }
        sumaColumnasAlerta += 'Columna ' + j + ': ' + sumaColumna + '\n';
    }

    var sumaDiagonalPrincipal = 0;
    for (var k = 0; k < Math.min(numFilas, numColumnas); k++) {
        sumaDiagonalPrincipal += matrizNueva[k][k];
    }
    var sumaDiagonalAlerta = 'Suma de diagonal principal: ' + sumaDiagonalPrincipal;

    alert(sumaFilasAlerta + '\n' + sumaColumnasAlerta + '\n' + sumaDiagonalAlerta);
});
        


        
        $("#boton_matriz_transpuesta").click(function () {
            var numRows = parseInt(prompt('Ingresa el número de filas:'));
            var numCols = parseInt(prompt('Ingresa el número de columnas:'));
        
            
            if (numRows !== numCols) {
                alert('El número de filas y columnas debe ser igual para crear una matriz cuadrada.');
                return; 
            }
        
            var matrizNueva = [];
        
            
            for (let i = 0; i < numRows; i++) {
                matrizNueva[i] = new Array(numCols);
                for (let j = 0; j < numCols; j++) {
                    matrizNueva[i][j] = parseInt(prompt(`Ingresa el valor para la fila ${i+1}, columna ${j+1}:`));
                }
            }
        
            
            var matrizText = "Matriz ingresada:\n";
            for (let i = 0; i < numRows; i++) {
                for (let j = 0; j < numCols; j++) {
                    matrizText += `${matrizNueva[i][j]}\t`; 
                }
                matrizText += "\n"; 
            }
        
            
            
            var matrizTranspuesta = [];
            for (let j = 0; j < numCols; j++) {
                matrizTranspuesta[j] = new Array(numRows);
                for (let i = 0; i < numRows; i++) {
                    matrizTranspuesta[j][i] = matrizNueva[i][j];
                }
            }
        
            
            var transpuestaText = "Matriz transpuesta:\n";
            for (let i = 0; i < numCols; i++) {
                for (let j = 0; j < numRows; j++) {
                    transpuestaText += (matrizTranspuesta[i][j]  + "\t" ); 
                }
                transpuestaText += "\n"; 
            }
            alert(matrizText + transpuestaText);
        
           

        
        });



        $("#boton_multiplicar_matrices").click(function () {

            var numRows1 = parseInt(prompt('Ingresa el número de filas de la primera matriz:'));
            var numCols1 = parseInt(prompt('Ingresa el número de columnas de la primera matriz:'));
        
            
            var numRows2 = parseInt(prompt('Ingresa el número de filas de la segunda matriz:'));
            var numCols2 = parseInt(prompt('Ingresa el número de columnas de la segunda matriz:'));
        
            
            if (numCols1 !== numRows2) {
                alert('El número de columnas de la primera matriz debe ser igual al número de filas de la segunda matriz para poder multiplicar.');
                return; 
            }

            var matriz1 = [];
            for (let i = 0; i < numRows1; i++) {
                matriz1[i] = [];
                for (let j = 0; j < numCols1; j++) {
                    matriz1[i][j] = parseInt(prompt(`Ingresa el valor para la primera matriz, fila ${i+1}, columna ${j+1}:`));
                }
            }
        
            
            var matriz2 = [];
            for (let i = 0; i < numRows2; i++) {
                matriz2[i] = [];
                for (let j = 0; j < numCols2; j++) {
                    matriz2[i][j] = parseInt(prompt(`Ingresa el valor para la segunda matriz, fila ${i+1}, columna ${j+1}:`));
                }
            }
        
            
            var matriz1Text = "Primera Matriz:\n";
            for (let i = 0; i < numRows1; i++) {
                for (let j = 0; j < numCols1; j++) {
                    matriz1Text += `${matriz1[i][j]}\t`;
                }
                matriz1Text += "\n"; 
            }
            alert(matriz1Text);
        
            var matriz2Text = "Segunda Matriz:\n";
            for (let i = 0; i < numRows2; i++) {
                for (let j = 0; j < numCols2; j++) {
                    matriz2Text += `${matriz2[i][j]}\t`; 
                }
                matriz2Text += "\n"; 
            }
            alert(matriz2Text);
        
            
            var resultadoMatriz = [];
            for (let i = 0; i < numRows1; i++) {
                resultadoMatriz[i] = [];
                for (let j = 0; j < numCols2; j++) {
                    resultadoMatriz[i][j] = 0;
                    for (let k = 0; k < numCols1; k++) {
                        resultadoMatriz[i][j] += matriz1[i][k] * matriz2[k][j];
                    }
                }
            }
            var resultadoText = "Resultado de la multiplicación de matrices:\n";
            for (let i = 0; i < numRows1; i++) {
                for (let j = 0; j < numCols2; j++) {
                    resultadoText += `${resultadoMatriz[i][j]}\t`; 
                }
                resultadoText += "\n"; 
            }
            alert(resultadoText);
        });
$("#boton_matriz_justicia").click(function () {
        var numRows = parseInt(prompt('Ingresa el número de filas:'));
        var numCols = parseInt(prompt('Ingresa el número de columnas:'));
    
        
        
    
        var matrizNueva = [];
    
        
        for (let i = 0; i < numRows; i++) {
            matrizNueva[i] = new Array(numCols);
            for (let j = 0; j < numCols; j++) {
                 matrizNueva[i][j] = parseInt(prompt('Ingresa el valor para la fila  '  + (i + 1) + ' , ' + 'columna   '  + (j + 1)  + ' :'  ));
            }
        }
    
        
        var matrizText = "Matriz ingresada:\n";
        for (let i = 0; i < numRows; i++) {
            for (let j = 0; j < numCols; j++) {
                matrizText += (matrizNueva[i][j] + '\t' ); 
            }
            matrizText += "\n"; 
        }
        alert(matrizText);
    
        
        var matrizInversaText = "Matriz en justicia divina 1.0 :\n";
        for (let i = numRows - 1; i >= 0; i--) {
            for (let j = numCols - 1; j >= 0; j--) {
                matrizInversaText += (matrizNueva[i][j] + '\t' ); 
            }
            matrizInversaText += "\n"; 
        }
        alert(matrizInversaText);
    });
    



    
        


    


        
        
});


  











